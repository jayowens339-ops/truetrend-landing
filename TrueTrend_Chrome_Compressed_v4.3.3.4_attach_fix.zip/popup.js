
(()=>{
  const $=s=>document.querySelector(s), out=$("#out");
  const mode=$("#mode"), confGate=$("#confGate");
  const symbol=$("#symbol"), timeframe=$("#timeframe"), strategy=$("#strategy"), voiceOn=$("#voiceOn");
  const autoVision=$("#autoVision"), autoVisionSec=$("#autoVisionSec"), flipOnly=$("#flipOnly");
  const voiceSel=$("#voiceSel"), vRate=$("#vRate"), vPitch=$("#vPitch"), vVol=$("#vVol");
  const tdKey=$("#tdKey"), polyKey=$("#polyKey"), fhKey=$("#fhKey"), gvKey=$("#gvKey");
  const polyStream=$("#polyStream"), trailing=$("#trailing"), compact=$("#compact");
  const show = o => out.textContent = JSON.stringify(o,null,2);
  function withTab(fn){ chrome.tabs.query({active:true,currentWindow:true}, tabs=>tabs[0]&&fn(tabs[0].id)); }

  chrome.tts.getVoices(vs=>{
    voiceSel.innerHTML=""; vs.forEach((v,i)=>{ const opt=document.createElement("option"); opt.value=String(i); opt.textContent=`${v.voiceName} ${v.lang?('('+v.lang+')'):''}`; opt.dataset.voiceName=v.voiceName; voiceSel.appendChild(opt); });
    chrome.storage.local.get(["voicePref","cfg","autoVisionCfg","modeCfg","gate","keys","streamCfg","uiPref"], r=>{
      const vp=r.voicePref||{voiceName:(vs[0]?.voiceName||""), rate:1, pitch:1, volume:1};
      voiceSel.value=String(Math.max(0,vs.findIndex(v=>v.voiceName===vp.voiceName))); vRate.value=vp.rate||1; vPitch.value=vp.pitch||1; vVol.value=vp.volume||1;
      const cfg=r.cfg||{};
      symbol.value=cfg.symbol||"AAPL"; timeframe.value=cfg.timeframe||"5min"; strategy.value=cfg.strategy||"router"; voiceOn.value=cfg.voiceOn||"on";
      const avc=r.autoVisionCfg||{on:true,sec:45,flipOnly:true}; autoVision.checked=avc.on; autoVisionSec.value=avc.sec; flipOnly.checked=!!avc.flipOnly;
      const m=r.modeCfg||{mode:"beginner"}; mode.value=m.mode||"beginner";
      const g=typeof r.gate==="number"? r.gate: 65; confGate.value=g;
      const keys=r.keys||{};
      if(!keys.td){ chrome.storage.local.set({ keys:{ td:tdKey.value, poly:polyKey.value, fh:fhKey.value, gv:gvKey.value } }); }
      const sc=r.streamCfg||{poly:"on",trail:"atr"}; polyStream.value=sc.poly||"off"; trailing.value=sc.trail||"off";
      const up=r.uiPref||{compact:"on"}; compact.value=up.compact||"on";
      pushAll();
    });
  });

  function pushAll(){ pushCfg(); pushMode(); pushGate(); pushAutoVision(); pushVoicePref(); pushKeys(); pushStreams(); pushUIPref(); }
  function saveCfg(){ chrome.storage.local.set({ cfg:{ symbol:symbol.value,timeframe:timeframe.value,strategy:strategy.value,voiceOn:voiceOn.value } }); pushCfg(); }
  [symbol,timeframe,strategy,voiceOn].forEach(el=>el.addEventListener("change",saveCfg));
  mode.addEventListener("change", ()=>{ chrome.storage.local.set({ modeCfg:{ mode:mode.value }}); pushMode(); });
  confGate.addEventListener("change", ()=>{ const v=Number(confGate.value||65); chrome.storage.local.set({ gate:v }); pushGate(); });
  [tdKey,polyKey,fhKey,gvKey].forEach(el=> el.addEventListener("change", pushKeys));
  [polyStream,trailing].forEach(el=> el.addEventListener("change", pushStreams));
  compact.addEventListener("change", pushUIPref);

  function pushCfg(){ withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_CFG",voiceOn:voiceOn.value==="on"})); chrome.runtime.sendMessage({ cmd:"TT_CFG_SAVE" }); }
  function pushMode(){ chrome.runtime.sendMessage({ cmd:"TT_MODE", mode:mode.value }); }
  function pushGate(){ chrome.runtime.sendMessage({ cmd:"TT_GATE", gate:Number(confGate.value||65) }); }
  function pushKeys(){ chrome.storage.local.set({ keys:{ td:tdKey.value, poly:polyKey.value, fh:fhKey.value, gv:gvKey.value } }); }
  function pushStreams(){ chrome.storage.local.set({ streamCfg:{ poly:polyStream.value, trail:trailing.value } }); chrome.runtime.sendMessage({ cmd:"TT_STREAM_TOGGLE", poly:polyStream.value, trail:trailing.value }); }
  function pushUIPref(){ chrome.storage.local.set({ uiPref:{ compact:compact.value } }); withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_UI_COMPACT", on: compact.value==="on"})); }

  function pushVoicePref(){
    const idx=Number(voiceSel.value||0);
    chrome.tts.getVoices(vs=>{
      const voiceName=vs[idx]?.voiceName || (vs[0]?.voiceName||"");
      const pref={ voiceName, rate:Number(vRate.value||1), pitch:Number(vPitch.value||1), volume:Number(vVol.value||1) };
      chrome.storage.local.set({ voicePref: pref });
    });
  }
  [voiceSel,vRate,vPitch,vVol].forEach(el=> el.addEventListener("change", pushVoicePref));

  autoVision.addEventListener("change", ()=>pushAutoVision());
  autoVisionSec.addEventListener("change", ()=>pushAutoVision());
  flipOnly.addEventListener("change", ()=>pushAutoVision());
  function pushAutoVision(){
    chrome.runtime.sendMessage({ cmd:"TT_AUTOVISION_CFG", on:autoVision.checked, sec:Number(autoVisionSec.value)||45,
      symbol:symbol.value, timeframe:timeframe.value, strategy:strategy.value, flipOnly:flipOnly.checked }, res=> show(res||{ok:false}));
  }

  $("#attach").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_ATTACH"})));
  $("#attachPick").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_ATTACH_PICK"})));
  $("#detach").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_DETACH"})));
  $("#analyze").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_ANALYZE", symbol:symbol.value, timeframe:timeframe.value, strategy:strategy.value }, res=> show(res||{ok:false})));
  $("#vision").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_VISION_RUN", provider:"google", symbol:symbol.value, timeframe:timeframe.value }, res=> show(res||{ok:false})));
  $("#test").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK", text:"TrueTrend voice check." }));
  $("#say").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK", text:"TrueTrend is ready." }));
  $("#replay").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK" }));
  $("#snapshot").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SNAPSHOT" }, res=> show(res||{ok:false})));
  $("#reset").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_RESET_ALERTS" }, res=> show(res||{ok:false})));
})();


/* Pre-Analyze attach + explicit Attach button (v4.3.3.4) */
(function(){
  function sendAttach(cb){
    try{
      withTab(t=> chrome.tabs.sendMessage(t, {type:"TT_ATTACH"}, resp=>{ (cb||function(){}) (resp);}));
    }catch(_){ (cb||function(){})(); }
  }
  // Ensure Attach button (#attach) sends TT_ATTACH
  try {
    const btnAttach = document.querySelector("#attach");
    if (btnAttach && !btnAttach.dataset.ttBind){
      btnAttach.dataset.ttBind = "1";
      btnAttach.addEventListener("click", ()=> sendAttach(), {capture:true, passive:true});
    }
  } catch(_){}

  // Wrap Analyze to attach first, then send analysis
  try {
    const btnAnalyze = document.querySelector("#analyze");
    if (btnAnalyze && !btnAnalyze.dataset.ttBindAttach){
      btnAnalyze.dataset.ttBindAttach = "1";
      btnAnalyze.addEventListener("click", (ev)=>{
        const symbol = (document.querySelector("#symbol")||{}).value || "";
        const timeframe = (document.querySelector("#timeframe")||{}).value || "";
        const strategy = (document.querySelector("#strategy")||{}).value || "";
        sendAttach(()=>{
          try{ chrome.runtime.sendMessage({ cmd:"TT_ANALYZE", symbol, timeframe, strategy }); }catch(_){}
        });
      }, {capture:true});
    }
  } catch(_){}
})();

