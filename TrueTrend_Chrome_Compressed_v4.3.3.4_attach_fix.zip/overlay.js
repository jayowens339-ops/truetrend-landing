
// overlay.js — legacy dock + compact mode + Scenario Slider + canvas guides + bottom pill + journal hint
(()=>{
  let mounted=false, layer=null, bar=null, anchorEl=null, rootEl=null;
  let attachObserver=null, resizeObs=null, intervalGuard=null, pill=null;
  let lastPlan=null, log=[], logLimit=14, compactOn=true;
  let slider=null, sliderVal=1.5, expEl=null;

  const DOMAIN_PROFILES=[
    { host:/tradingview\.com$/i, selector:'[data-name="pane"], [class*="chart-container"], [class*="tv-chart-view__pane"]' },
    { host:/investing\.com$/i,   selector:'#chart-inner-content, #tv_chart_container, .js-chart-ui-container' },
    { host:/finance\.yahoo\.com$/i, selector:'#Main, #myLightboxContainer, [id*="chart"]' },
    { host:/.*/, selector:null }
  ];

  function findProfileRoot(){
    const host=location.hostname;
    for(const p of DOMAIN_PROFILES){
      if(p.host.test(host)){
        if(!p.selector) break;
        const el=document.querySelector(p.selector);
        if(el) return el;
      }
    }
    return null;
  }
  function findLargestChartElement(){
    const c=[...document.querySelectorAll("canvas,svg"),
     ...[...document.querySelectorAll("div,section,main")].filter(e=>/chart|graph|pane|canvas|tv|price/i.test(e.className||""))]
     .filter(el=>{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>300&&r.height>200&&s.display!=="none"&&s.visibility!=="hidden"});
    c.sort((a,b)=>(b.clientWidth*b.clientHeight)-(a.clientWidth*a.clientHeight));
    return c[0]||document.body;
  }
  function getRoot(){ if(anchorEl&&document.contains(anchorEl)) return anchorEl.closest("div,section,main,body")||document.body;
    return findProfileRoot()||findLargestChartElement(); }

  function ensureLayer(){
    const root=getRoot(); if(!root) return;
    rootEl=root;
    if(!layer){
      layer=document.createElement("div");
      layer.id="tt_layer";
      Object.assign(layer.style,{position:"absolute",inset:"0",pointerEvents:"none",zIndex:2147483600});
      const cs=getComputedStyle(root); if(cs.position==="static") root.style.position="relative";
      root.appendChild(layer);
    } else if(!root.contains(layer)){ root.appendChild(layer); }
  }

  function mountDock(){
    ensureLayer();
    if(!bar){
      bar=document.createElement("div");
      bar.id="tt_bar";
      bar.dataset.docked="1";
      bar.innerHTML=`<div class="tt-row">
        <b class="tt-brand">TrueTrend</b>
        <span id="tt_str" class="hideCompact">—</span>
        <span id="tt_dir">—</span>
        <span id="tt_en" class="hideCompact">E: —</span>
        <span id="tt_sl" class="hideCompact">SL: —</span>
        <span id="tt_tp" class="hideCompact">TP: —</span>
        <div id="tt_conf" class="tt-chip hideCompact">C 0%</div>
        <div id="tt_heat" class="tt-heat hideCompact"></div>
        <span class="tt-right">
          <button data-cmd="replay" title="Replay">🔊</button>
          <button data-cmd="copy" title="Copy">📋</button>
          <button data-cmd="why"  title="Why?">❓</button>
          <button data-cmd="log"  title="Log">🧾</button>
          <button data-cmd="compact" class="tt-col" title="Compact/Full">⇲</button>
          <button data-cmd="close" class="tt-reset" title="Hide">Hide</button>
        </span>
      </div>
      <div id="tt_log" style="display:none;margin-top:6px;max-height:120px;overflow:auto;background:rgba(255,255,255,.06);border:1px solid #2a3247;border-radius:8px;padding:6px"></div>
      <div id="tt_scenario" class="tt-scen">
        <label>Scenario TP multiple <input id="tt_slider" type="range" min="0.5" max="3" step="0.1" value="1.5"></label>
        <div id="tt_exp">Exp: —</div>
      </div>
      <canvas id="tt_canvas" style="position:absolute;inset:0;pointer-events:none;"></canvas>`;
      Object.assign(bar.style,{
        position:"absolute",left:"0",right:"0",bottom:"0",
        minHeight:"24px",height:"32px",
        pointerEvents:"auto",
        background:"rgba(10,13,22,.54)",
        backdropFilter:"blur(4px)",
        color:"#eaf0ff",
        borderTop:"1px solid #223",
        padding:"4px 8px",
        font:"12px system-ui,Segoe UI,Arial",
        borderRadius:"10px 10px 0 0",
        transition:"height .12s ease, opacity .12s ease, background .2s ease"
      });
      const css=document.createElement("style");
      css.textContent=`
        .tt-row{display:flex;align-items:center;gap:8px;width:100%}
        .tt-brand{min-width:76px;font-weight:700}
        #tt_bar button{padding:3px 6px;border-radius:8px;border:0;cursor:pointer;background:rgba(255,255,255,.06);color:#eaf0ff}
        #tt_bar .tt-col{padding:2px 6px}
        #tt_bar .tt-chip{margin-left:8px;padding:1px 6px;border-radius:10px;background:rgba(255,255,255,.06);border:1px solid #2a3247}
        #tt_bar .tt-heat{display:flex;gap:2px;margin-left:6px}
        #tt_bar .tt-right{margin-left:auto;display:flex;gap:6px;align-items:center}
        .tt-pop{position:absolute;background:#0b0f1a;color:#eaf0ff;border:1px solid #223;border-radius:8px;padding:8px;bottom:40px;left:12px;white-space:nowrap;box-shadow:0 6px 14px rgba(0,0,0,.35);z-index:10}
        .tt-pill{position:fixed;left:50%;transform:translateX(-50%);bottom:10px;padding:6px 10px;background:#0b0f1a;color:#eaf0ff;border:1px solid #223;border-radius:20px;z-index:2147483601;cursor:pointer;box-shadow:0 6px 14px rgba(0,0,0,.35)}
        .tt-scen{display:flex;align-items:center;gap:10px;margin-top:4px}
        .tt-scen label{display:flex;align-items:center;gap:8px}
        .hideCompact{display:none}
        .full .hideCompact{display:inline}
        @keyframes ttGlow{0%{box-shadow:0 0 0 rgba(31,196,107,0)}30%{box-shadow:0 0 18px rgba(31,196,107,.7)}100%{box-shadow:0 0 0 rgba(31,196,107,0)}}
      `;
      document.head.appendChild(css);
      layer.appendChild(bar);

      slider=bar.querySelector("#tt_slider"); expEl=bar.querySelector("#tt_exp");
      slider.addEventListener("input", ()=>{
        sliderVal = Number(slider.value||1.5);
        chrome.runtime.sendMessage({ cmd:"TT_SCENARIO", tpMult: sliderVal }, res=>{
          if(res && typeof res.exp==="number"){
            expEl.textContent = `Exp: ${res.exp.toFixed(3)}R`;
          }else{
            expEl.textContent = "Exp: —";
          }
        });
      });

      bar.addEventListener("mouseenter", ()=>{ if(bar.dataset.collapsed==="1"){bar.style.height="28px";bar.style.opacity="1"}; bar.style.background="rgba(10,13,22,.95)"; });
      bar.addEventListener("mouseleave", ()=>{ if(bar.dataset.collapsed==="1"){bar.style.height="22px";bar.style.opacity="0.9"}; bar.style.background="rgba(10,13,22,.54)"; });
      bar.addEventListener("click", e=>{
        const cmd=e.target?.dataset?.cmd;
        if(cmd==="compact"){
          compactOn=!compactOn; bar.classList.toggle("full", !compactOn);
        }
        if(cmd==="close"){ showPill(); bar.style.display="none"; }
        if(cmd==="replay"){ chrome.runtime.sendMessage({ cmd:"TT_SPEAK" }); }
        if(cmd==="copy"){
          const en=document.getElementById("tt_en").textContent||"";
          const sl=document.getElementById("tt_sl").textContent||"";
          const tp=document.getElementById("tt_tp").textContent||"";
          navigator.clipboard.writeText([en,sl,tp].join("\\n")).catch(()=>{});
        }
        if(cmd==="log"){
          const el=bar.querySelector("#tt_log");
          el.style.display = (el.style.display==="none")?"block":"none";
        }
        if(cmd==="why"){
          const pop=document.createElement("div");
          pop.className="tt-pop";
          pop.textContent = (lastPlan?.whyShort) || "EMA/ATR regime";
          bar.appendChild(pop);
          setTimeout(()=>pop.remove(), 1800);
        }
      });
    }
    sizeCanvas();
  }

  function sizeCanvas(){
    const cvs = bar.querySelector("#tt_canvas"); if(!cvs) return;
    const r = (layer||document.body).getBoundingClientRect();
    cvs.width = r.width; cvs.height = r.height;
    cvs.style.width = r.width+"px"; cvs.style.height = r.height+"px";
  }

  function showPill(){
    if(pill && document.body.contains(pill)) return;
    pill=document.createElement("div");
    pill.className="tt-pill";
    pill.textContent="TrueTrend — restore";
    pill.addEventListener("click", ()=>{ if(bar){ bar.style.display=""; } if(pill) pill.remove(); });
    document.body.appendChild(pill);
  }

  function pulse(){ if(!bar) return; bar.style.animation="ttGlow 1200ms ease"; setTimeout(()=>{ if(bar) bar.style.animation="none"; }, 1300); }
  function paintHeatmap(arr){
    const heat = bar?.querySelector("#tt_heat"); if(!heat) return;
    heat.innerHTML=""; (arr||[]).slice(-10).forEach(v=>{
      const dot=document.createElement("div");
      Object.assign(dot.style,{width:"8px",height:"8px",borderRadius:"2px",background: v==="BUY"?"#1fc46b":"#f55757",opacity:.85});
      heat.appendChild(dot);
    });
  }
  function renderLog(){
    const el=bar?.querySelector("#tt_log"); if(!el) return;
    const fmt = (x)=>{ const ts=new Date(x.ts).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}); return `[${ts}] ${x.strategy} ${x.direction} — E:${x.entry} SL:${x.stopLoss} TP:${x.takeProfit} (C${x.confidence}%)`; };
    el.innerHTML = log.slice(-logLimit).map(x=>`<div>${fmt(x)}</div>`).join("");
  }

  function drawGuides(plan){
    const cvs = bar?.querySelector("#tt_canvas"); if(!cvs) return;
    const ctx = cvs.getContext("2d"); const W=cvs.width, H=cvs.height;
    ctx.clearRect(0,0,W,H);
    const pad=40; const baseY=H*0.65; const gap=20;
    let yEntry=baseY, ySL=baseY+gap, yTP=baseY-gap;
    if(plan.direction==="SELL"){ yEntry=baseY; ySL=baseY-gap; yTP=baseY+gap; }
    // Entry (black dotted)
    ctx.setLineDash([6,6]); ctx.strokeStyle="#111"; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(0,yEntry); ctx.lineTo(W,yEntry); ctx.stroke();
    // Stop (red solid)
    ctx.setLineDash([]); ctx.strokeStyle="#ef4444"; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(0,ySL); ctx.lineTo(W,ySL); ctx.stroke();
    // TP (green dotted)
    ctx.setLineDash([4,6]); ctx.strokeStyle="#1fc46b"; ctx.lineWidth=2;
    ctx.beginPath(); ctx.moveTo(0,yTP); ctx.lineTo(W,yTP); ctx.stroke();
    // Badges
    ctx.font="12px system-ui,Segoe UI,Arial"; ctx.fillStyle="#eaf0ff";
    ctx.fillText("↗ Entry "+(plan.entry!=null?Number(plan.entry).toFixed(5):""), 10, yEntry-6);
    ctx.fillText("✖ Stop "+(plan.stopLoss!=null?Number(plan.stopLoss).toFixed(5):""), 10, ySL-6);
    ctx.fillText("💰 TP "+(plan.takeProfit!=null?Number(plan.takeProfit).toFixed(5):""), 10, yTP-6);
  }

  function startGuards(){
    if(attachObserver) try{ attachObserver.disconnect(); }catch(_){}
    attachObserver = new MutationObserver(()=>{
      if(!layer || !rootEl) return;
      if(!rootEl.contains(layer)){
        try{ rootEl.appendChild(layer); }catch(_){ document.body.appendChild(layer); }
      }
    });
    attachObserver.observe(document.documentElement, { childList:true, subtree:true });

    if(resizeObs) try{ resizeObs.disconnect(); }catch(_){}
    resizeObs = new ResizeObserver(()=>{ sizeCanvas(); });
    resizeObs.observe(document.documentElement);

    if(intervalGuard) clearInterval(intervalGuard);
    intervalGuard = setInterval(()=>{
      if(!rootEl || !layer || !bar) return;
      const r = rootEl.getBoundingClientRect();
      if(r.height<120){ bar.style.position="fixed"; bar.style.left="0"; bar.style.right="0"; bar.style.bottom="0"; }
      if(!layer.contains(bar)){ layer.appendChild(bar); }
      layer.style.zIndex="2147483600";
      sizeCanvas();
    }, 1200);
  }

  function update(plan){
    mountDock(); if(!bar) return;
    lastPlan=plan;
    const confEl = bar.querySelector("#tt_conf");
    bar.querySelector("#tt_str").textContent = plan.strategy||"Router";
    bar.querySelector("#tt_dir").textContent = plan.direction==="BUY"?"BUY ✅":"SELL ⛔";
    bar.querySelector("#tt_en").textContent  = "E: "+(plan.entry!=null?Number(plan.entry).toFixed(5):"—");
    bar.querySelector("#tt_sl").textContent  = "SL: "+(plan.stopLoss!=null?Number(plan.stopLoss).toFixed(5):"—");
    bar.querySelector("#tt_tp").textContent  = "TP: "+(plan.takeProfit!=null?Number(plan.takeProfit).toFixed(5):"—");
    const conf = Math.max(0,Math.min(100,Number(plan.confidence||0)))|0;
    confEl.textContent = `C ${conf}%`;
    confEl.style.borderColor = plan.direction==="BUY"?"#1e7a4f":"#7a1e1e";
    paintHeatmap(plan.heat||[]);
    drawGuides(plan);
    pulse();
    log.push({ ...plan, ts: Date.now() }); log=log.slice(-logLimit); renderLog();
  }

  function destroy(){
    if(attachObserver) try{ attachObserver.disconnect(); }catch(_){}
    if(resizeObs) try{ resizeObs.disconnect(); }catch(_){}
    if(intervalGuard) clearInterval(intervalGuard);
    attachObserver=resizeObs=intervalGuard=null;
    if(layer?.parentElement) layer.parentElement.removeChild(layer);
    if(pill?.parentElement) pill.parentElement.removeChild(pill);
    layer=null; bar=null; mounted=false; lastPlan=null; log=[];
  }

  chrome.runtime.onMessage.addListener((msg,_,send)=>{
    if(msg?.type==="TT_ATTACH"){ mounted=true; mountDock(); startGuards(); send&&send({ok:true}); }
    if(msg?.type==="TT_ATTACH_PICK"){ mounted=true; anchorEl=findLargestChartElement(); mountDock(); startGuards(); send&&send({ok:true}); }
    if(msg?.type==="TT_DETACH"){ destroy(); send&&send({ok:true}); }
    if(msg?.type==="TT_LEVELS" && mounted){ update(msg.payload||{}); send&&send({ok:true}); }
    if(msg?.type==="TT_CFG"){ send&&send({ok:true}); }
    if(msg?.type==="TT_UI_COMPACT"){ compactOn = !!msg.on; if(bar){ bar.classList.toggle("full", !compactOn); } send&&send({ok:true}); }
  });

// TT_ATTACH handler (v4.3.3.4)
try {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if (msg && msg.type === "TT_ATTACH") {
      try {
        if (!mounted) { mounted = true; mountDock(); startGuards(); }
        sendResponse && sendResponse({ok:true, attached:true});
      } catch(e){
        try{ sendResponse && sendResponse({ok:false, error:e.message}); }catch(_){}
      }
      return true;
    }
  });
} catch(_){}
})();
