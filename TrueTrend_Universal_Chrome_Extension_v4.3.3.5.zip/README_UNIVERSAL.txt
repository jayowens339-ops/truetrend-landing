TrueTrend Ultimate (Universal v4.1) — v4.3.3.5 (Universal Chrome Extension)
Install on Windows or Mac:
1) Unzip this file.
2) Open chrome://extensions in Chrome.
3) Turn on Developer mode.
4) Click "Load unpacked" and select the unzipped folder.