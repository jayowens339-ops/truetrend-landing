
(()=>{
  const $=s=>document.querySelector(s), out=$("#out");
  const mode=$("#mode"), confGate=$("#confGate");
  const symbol=$("#symbol"), timeframe=$("#timeframe"), strategy=$("#strategy"), voiceOn=$("#voiceOn");
  const autoVision=$("#autoVision"), autoVisionSec=$("#autoVisionSec"), flipOnly=$("#flipOnly");
  const voiceSel=$("#voiceSel"), vRate=$("#vRate"), vPitch=$("#vPitch"), vVol=$("#vVol");
  const tdKey=$("#tdKey"), polyKey=$("#polyKey"), fhKey=$("#fhKey"), gvKey=$("#gvKey");
  const polyStream=$("#polyStream"), trailing=$("#trailing"), compact=$("#compact");
  const show = o => out.textContent = JSON.stringify(o,null,2);
  function withTab(fn){ chrome.tabs.query({active:true,currentWindow:true}, tabs=>tabs[0]&&fn(tabs[0].id)); }

  chrome.tts.getVoices(vs=>{
    voiceSel.innerHTML=""; vs.forEach((v,i)=>{ const opt=document.createElement("option"); opt.value=String(i); opt.textContent=`${v.voiceName} ${v.lang?('('+v.lang+')'):''}`; opt.dataset.voiceName=v.voiceName; voiceSel.appendChild(opt); });
    chrome.storage.local.get(["voicePref","cfg","autoVisionCfg","modeCfg","gate","keys","streamCfg","uiPref"], r=>{
      const vp=r.voicePref||{voiceName:(vs[0]?.voiceName||""), rate:1, pitch:1, volume:1};
      voiceSel.value=String(Math.max(0,vs.findIndex(v=>v.voiceName===vp.voiceName))); vRate.value=vp.rate||1; vPitch.value=vp.pitch||1; vVol.value=vp.volume||1;
      const cfg=r.cfg||{};
      symbol.value=cfg.symbol||"AAPL"; timeframe.value=cfg.timeframe||"5min"; strategy.value=cfg.strategy||"router"; voiceOn.value=cfg.voiceOn||"on";
      const avc=r.autoVisionCfg||{on:true,sec:45,flipOnly:true}; autoVision.checked=avc.on; autoVisionSec.value=avc.sec; flipOnly.checked=!!avc.flipOnly;
      const m=r.modeCfg||{mode:"beginner"}; mode.value=m.mode||"beginner";
      const g=typeof r.gate==="number"? r.gate: 65; confGate.value=g;
      const keys=r.keys||{};
      if(!keys.td){ chrome.storage.local.set({ keys:{ td:tdKey.value, poly:polyKey.value, fh:fhKey.value, gv:gvKey.value } }); }
      const sc=r.streamCfg||{poly:"on",trail:"atr"}; polyStream.value=sc.poly||"off"; trailing.value=sc.trail||"off";
      const up=r.uiPref||{compact:"on"}; compact.value=up.compact||"on";
      pushAll();
    });
  });

  function pushAll(){ pushCfg(); pushMode(); pushGate(); pushAutoVision(); pushVoicePref(); pushKeys(); pushStreams(); pushUIPref(); }
  function saveCfg(){ chrome.storage.local.set({ cfg:{ symbol:symbol.value,timeframe:timeframe.value,strategy:strategy.value,voiceOn:voiceOn.value } }); pushCfg(); }
  [symbol,timeframe,strategy,voiceOn].forEach(el=>el.addEventListener("change",saveCfg));
  mode.addEventListener("change", ()=>{ chrome.storage.local.set({ modeCfg:{ mode:mode.value }}); pushMode(); });
  confGate.addEventListener("change", ()=>{ const v=Number(confGate.value||65); chrome.storage.local.set({ gate:v }); pushGate(); });
  [tdKey,polyKey,fhKey,gvKey].forEach(el=> el.addEventListener("change", pushKeys));
  [polyStream,trailing].forEach(el=> el.addEventListener("change", pushStreams));
  compact.addEventListener("change", pushUIPref);

  function pushCfg(){ withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_CFG",voiceOn:voiceOn.value==="on"})); chrome.runtime.sendMessage({ cmd:"TT_CFG_SAVE" }); }
  function pushMode(){ chrome.runtime.sendMessage({ cmd:"TT_MODE", mode:mode.value }); }
  function pushGate(){ chrome.runtime.sendMessage({ cmd:"TT_GATE", gate:Number(confGate.value||65) }); }
  function pushKeys(){ chrome.storage.local.set({ keys:{ td:tdKey.value, poly:polyKey.value, fh:fhKey.value, gv:gvKey.value } }); }
  function pushStreams(){ chrome.storage.local.set({ streamCfg:{ poly:polyStream.value, trail:trailing.value } }); chrome.runtime.sendMessage({ cmd:"TT_STREAM_TOGGLE", poly:polyStream.value, trail:trailing.value }); }
  function pushUIPref(){ chrome.storage.local.set({ uiPref:{ compact:compact.value } }); withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_UI_COMPACT", on: compact.value==="on"})); }

  function pushVoicePref(){
    const idx=Number(voiceSel.value||0);
    chrome.tts.getVoices(vs=>{
      const voiceName=vs[idx]?.voiceName || (vs[0]?.voiceName||"");
      const pref={ voiceName, rate:Number(vRate.value||1), pitch:Number(vPitch.value||1), volume:Number(vVol.value||1) };
      chrome.storage.local.set({ voicePref: pref });
    });
  }
  [voiceSel,vRate,vPitch,vVol].forEach(el=> el.addEventListener("change", pushVoicePref));

  autoVision.addEventListener("change", ()=>pushAutoVision());
  autoVisionSec.addEventListener("change", ()=>pushAutoVision());
  flipOnly.addEventListener("change", ()=>pushAutoVision());
  function pushAutoVision(){
    chrome.runtime.sendMessage({ cmd:"TT_AUTOVISION_CFG", on:autoVision.checked, sec:Number(autoVisionSec.value)||45,
      symbol:symbol.value, timeframe:timeframe.value, strategy:strategy.value, flipOnly:flipOnly.checked }, res=> show(res||{ok:false}));
  }

  $("#attach").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_ATTACH"})));
  $("#attachPick").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_ATTACH_PICK"})));
  $("#detach").addEventListener("click", ()=> withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_DETACH"})));
  $("#analyze").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_ANALYZE", symbol:symbol.value, timeframe:timeframe.value, strategy:strategy.value }, res=> show(res||{ok:false})));
  $("#vision").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_VISION_RUN", provider:"google", symbol:symbol.value, timeframe:timeframe.value }, res=> show(res||{ok:false})));
  $("#test").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK", text:"TrueTrend voice check." }));
  $("#say").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK", text:"TrueTrend is ready." }));
  $("#replay").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SPEAK" }));
  $("#snapshot").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_SNAPSHOT" }, res=> show(res||{ok:false})));
  $("#reset").addEventListener("click", ()=> chrome.runtime.sendMessage({ cmd:"TT_RESET_ALERTS" }, res=> show(res||{ok:false})));
})();


/* TrueTrend patch — only-groups + smooth + attach-first */
(function(){
  if (window.__tt_ogs_init__) return; window.__tt_ogs_init__=true;
  const TIMEFRAMES = ["1 min","5 min","15 min","30 min","1 hour","4 hours","Daily","Monthly"];
  const OPT = ["Covered Call","Cash-Secured Put (CSP)","Wheel","Long Call","Long Put","Debit Call Spread","Debit Put Spread","Credit Call Spread","Credit Put Spread","Iron Condor","Iron Butterfly","Broken Wing Butterfly","Collar","Protective Put","PMCC (LEAPS Covered Call)","Calendar","Diagonal","Straddle","Strangle","Short Straddle","Short Strangle","Box Spread"];
  const FFX = ["EMA Trend (9/50)","RSI Divergence","MACD Cross","Bollinger Bounce","Donchian/Turtle Breakout","Opening Range Breakout (ORB)","Support/Resistance","Ichimoku Trend","Pivot Bounce","Fibonacci Pullback","Momentum (ROC)","Mean Reversion","Range Scalping (M1/M5)","Swing (H4/D1)","Heikin-Ashi Trend","ADR Breakout","Keltner Breakout","Carry Trade (FX)"];
  const makeOption = (label)=>{ const o=document.createElement("option"); o.value=label; o.textContent=label; o.style.color="#111827"; o.style.backgroundColor="#ffffff"; return o; };

  function setTimeframes(){
    const sel=document.querySelector("#timeframe"); if(!sel) return;
    const cur = (sel.value || sel.options[sel.selectedIndex]?.textContent || "").trim();
    while(sel.firstChild) sel.removeChild(sel.firstChild);
    TIMEFRAMES.forEach(l=>{ const x=makeOption(l); if((!cur&&l==="5 min")||cur===l) x.selected=true; sel.appendChild(x); });
  }
  function setStrategiesOnly(){
    const sel=document.querySelector("#strategy"); if(!sel) return;
    while(sel.firstChild) sel.removeChild(sel.firstChild);
    const g1=document.createElement("optgroup"); g1.label="Stock Options";
    OPT.forEach(n=>g1.appendChild(makeOption(n)));
    const g2=document.createElement("optgroup"); g2.label="Futures & Forex";
    FFX.forEach(n=>g2.appendChild(makeOption(n)));
    g1.style.color="#334155"; g1.style.backgroundColor="#ffffff";
    g2.style.color="#334155"; g2.style.backgroundColor="#ffffff";
    sel.appendChild(g1); sel.appendChild(g2);

    if(!sel.dataset.ttDebounce){
      sel.dataset.ttDebounce="1";
      let t=null, lastVal=sel.value;
      const go=()=>{ if(t) clearTimeout(t); t=setTimeout(()=>{
        if (sel.value===lastVal) return; lastVal=sel.value;
        const attachThenAnalyze = ()=>{
          try{ chrome.runtime.sendMessage({cmd:"TT_ATTACH_BEFORE_ANALYZE"}); }catch(_){}
          const btn=[...document.querySelectorAll('button,[role="button"],.btn,.button')].find(b=>/analy[sz]e/i.test((b.textContent||"").trim()));
          if(btn){ btn.click(); return; }
          try{ chrome.runtime.sendMessage({ cmd:"TT_ANALYZE", symbol:(document.querySelector("#symbol")||{}).value||"", timeframe:(document.querySelector("#timeframe")||{}).value||"", strategy: sel.value }); }catch(_){}
        };
        attachThenAnalyze();
      }, 220); };
      sel.addEventListener("change", go, {capture:true, passive:true});
      sel.addEventListener("input", go, {capture:true, passive:true});
    }
  }
  function init(){ setTimeframes(); setStrategiesOnly(); }
  if(document.readyState==="loading") document.addEventListener("DOMContentLoaded", init); else init();
})();


/* Attach first, then analyze (popup buttons) */
(function(){
  function sendAttach(cb){
    try{ withTab(t=> chrome.tabs.sendMessage(t,{type:"TT_ATTACH"}, resp=> (cb||function(){})(resp))); }catch(_){ (cb||function(){})(); }
  }
  // Attach button
  try{ const a=document.querySelector("#attach"); if(a && !a.dataset.ttBind){ a.dataset.ttBind="1"; a.addEventListener("click", ()=> sendAttach(), {capture:true}); } }catch(_){}
  // Analyze button
  try{ const b=document.querySelector("#analyze"); if(b && !b.dataset.ttBindAttach){ b.dataset.ttBindAttach="1"; b.addEventListener("click", (ev)=>{ const sym=(document.querySelector("#symbol")||{}).value||""; const tf=(document.querySelector("#timeframe")||{}).value||""; const st=(document.querySelector("#strategy")||{}).value||""; sendAttach(()=>{ try{ chrome.runtime.sendMessage({cmd:"TT_ANALYZE", symbol:sym, timeframe:tf, strategy:st}); }catch(_){}}); }, {capture:true}); } }catch(_){}
})();

