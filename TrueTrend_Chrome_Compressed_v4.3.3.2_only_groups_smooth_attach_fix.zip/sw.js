
// sw.js — v4.1: EMA/ATR engine, Feature Store+Voter, Polygon WS streaming, Scenario expectancy, Breakeven+Trailing, Journal
chrome.runtime.onInstalled.addListener(()=>{});

let gate = 65;
let mode = "beginner";
let lastText = "";

const state = {
  heatMap: {},     // key -> last 10 BUY/SELL
  lastDirMap: {},  // key -> last direction for flip‑guard
  featureStore: {},// key -> [{ts, dir, entry, sl, tp, resultR?}]
  openTrades: {},  // key -> { dir, entry, sl, tp, atr, tp1R:1.0, hitTP1:false, trailing:"atr"|"off" }
  stream: { on:false, trail:"atr", ws:null, product:"stocks", subs:[] },
  keys: { td:"", poly:"", fh:"", gv:"" },
  cfg: { voiceOn:"on" }
};

const tfMap = { "1min":"1min", "5min":"5min", "15min":"15min", "60min":"60min", "daily":"1day" };

function normalizeSymbol(sym){
  if(/^C:?[A-Z]{6}$/.test(sym)){ const p=sym.replace(/^C:/,""); return "C:"+p; }
  return sym;
}

async function loadKeys(){ return await new Promise(res=> chrome.storage.local.get(["keys"], r=>res(r.keys||{}))); }

async function fetchSeries(symbol, timeframe){
  const sym = normalizeSymbol(symbol);
  const keys = await loadKeys();
  const key = keys.td || "";
  const interval = tfMap[timeframe] || "5min";
  const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(sym)}&interval=${interval}&outputsize=200&format=JSON&apikey=${encodeURIComponent(key)}`;
  const r = await fetch(url);
  const j = await r.json();
  if(!j || !j.values) throw new Error("No series");
  const bars = j.values.map(b=>({ t:new Date(b.datetime), open:+b.open, high:+b.high, low:+b.low, close:+b.close })).reverse();
  return bars;
}

function ema(arr, len){
  const k = 2/(len+1); let e = arr[0]; const out=[e];
  for(let i=1;i<arr.length;i++){ e = arr[i]*k + e*(1-k); out.push(e); }
  return out;
}
function atr(bars, len=14){
  const trs=[]; for(let i=1;i<bars.length;i++){
    const h=bars[i].high, l=bars[i].low, pc=bars[i-1].close;
    const tr = Math.max(h-l, Math.abs(h-pc), Math.abs(l-pc));
    trs.push(tr);
  }
  const k=2/(len+1); let a=trs[0]||0; for(let i=1;i<trs.length;i++){ a = trs[i]*k + a*(1-k); }
  return a || 0;
}

function voteDirection(bars, strategy){
  const closes = bars.map(b=>b.close);
  const e9 = ema(closes,9).slice(-1)[0];
  const e21= ema(closes,21).slice(-1)[0];
  const last = closes.slice(-1)[0];
  const _atr = atr(bars,14);
  const vol = _atr / Math.max(1e-6,last);

  let votes = [];
  // EMA vote
  votes.push({ name:"ema", dir: e9>=e21?"BUY":"SELL", w: mode==="pro"?0.45:0.5 });
  // Momentum
  const mom = last - closes.slice(-5,-4)[0];
  votes.push({ name:"mom", dir: mom>=0?"BUY":"SELL", w: 0.2 });
  // ORB coarse (first 6 median)
  const first6 = bars.slice(0,6).map(b=>b.close); const m = first6.sort((a,b)=>a-b)[Math.floor(first6.length/2)];
  votes.push({ name:"orb", dir: last>=m?"BUY":"SELL", w: 0.15 });
  // BOS coarse (20-high/low)
  const recent = closes.slice(-20); const hi=Math.max(...recent), lo=Math.min(...recent);
  const bosDir = (last>hi*0.995) ? "BUY" : (last<lo*1.005) ? "SELL" : (e9>=e21?"BUY":"SELL");
  votes.push({ name:"bos", dir: bosDir, w: 0.2 });

  // Strategy bias
  if(strategy==="ema") votes.push({name:"bias", dir: e9>=e21?"BUY":"SELL", w:0.15});
  if(strategy==="supertrend") votes.push({name:"bias", dir: last>=e21?"BUY":"SELL", w:0.15});
  if(strategy==="orb") votes.push({name:"bias", dir: last>=m?"BUY":"SELL", w:0.15});
  if(strategy==="bos") votes.push({name:"bias", dir: bosDir, w:0.15});

  let score = votes.reduce((s,v)=> s + (v.dir==="BUY"? v.w: -v.w), 0);
  const dir = score>=0 ? "BUY":"SELL";
  const emaGap = Math.abs(e9-e21)/Math.max(1e-6,last);
  let conf = Math.min(95, Math.max(40, Math.round(50 + score*40 + emaGap*900 + (vol<0.01?10:0))));
  return { dir, conf, last, _atr };
}

function makePlan(symbol,timeframe,strategy,bars){
  const { dir, conf, last, _atr } = voteDirection(bars, strategy);
  const entry = last;
  const stop  = dir==="BUY" ? +(last - 1.0*_atr).toFixed(5) : +(last + 1.0*_atr).toFixed(5);
  const tp1   = dir==="BUY" ? +(last + 1.0*_atr).toFixed(5) : +(last - 1.0*_atr).toFixed(5);
  const tp2   = dir==="BUY" ? +(last + 1.5*_atr).toFixed(5) : +(last - 1.5*_atr).toFixed(5);
  const plan = { symbol, timeframe, strategy, direction:dir, entry:+entry.toFixed(5), stopLoss:stop, takeProfit:tp2, tp1, confidence:conf,
    whyShort: `Voter ${dir} · EMA9/21 gap · ATR ${_atr.toFixed(4)}` };
  return { plan, atr:_atr };
}

function keyFor(symbol,timeframe,strategy){ return [symbol,timeframe,strategy].join("|"); }

function pushPlan(plan, speak){
  chrome.storage.local.get(["voicePref","cfg","heatMap"], data=>{
    const heatMap = data.heatMap || {};
    const key = keyFor(plan.symbol,plan.timeframe,plan.strategy);
    const list = heatMap[key] || [];
    list.push(plan.direction); heatMap[key] = list.slice(-10);
    plan.heat = heatMap[key];
    chrome.storage.local.set({ heatMap });

    chrome.tabs.query({active:true,currentWindow:true}, tabs=>{
      if(tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type:"TT_LEVELS", payload: plan });
    });

    if(speak){
      const cfg=data.cfg||{voiceOn:"on"};
      if(cfg.voiceOn==="on"){
        const vp=data.voicePref||{};
        lastText = `${plan.strategy} ${plan.direction==='BUY'?'buy':'sell'} signal. Entry ${plan.entry}. Stop ${plan.stopLoss}. Target ${plan.takeProfit}.`;
        chrome.tts.speak(lastText, { voiceName: vp.voiceName, rate: vp.rate||1, pitch: vp.pitch||1, volume: vp.volume||1, enqueue:false });
      }
    }
  });
}

async function computeAndEmit(symbol,timeframe,strategy,{flipOnly=false}={}){
  try{
    const bars = await fetchSeries(symbol,timeframe);
    const { plan, atr } = makePlan(symbol,timeframe,strategy,bars);
    if(plan.confidence < gate){ pushPlan(plan,false); return {ok:true, gated:true, plan}; }
    const k = keyFor(symbol,timeframe,strategy);
    if(!flipOnly){ pushPlan(plan,true); }
    else {
      const last = state.lastDirMap[k];
      if(!last || last!==plan.direction){ state.lastDirMap[k]=plan.direction; pushPlan(plan,true); }
      else pushPlan(plan,false);
    }
    // open trade tracking
    state.openTrades[k] = { dir: plan.direction, entry:plan.entry, sl:plan.stopLoss, tp:plan.takeProfit, tp1: plan.tp1, atr, hitTP1:false, trailing: state.stream.trail };
    // feature store append (without result yet)
    const arr = state.featureStore[k] || (state.featureStore[k]=[]);
    arr.push({ ts:Date.now(), dir:plan.direction, entry:plan.entry, sl:plan.stopLoss, tp:plan.takeProfit });
    trimFeatureStore(k);
    return {ok:true, plan};
  }catch(e){
    return {ok:false, error:String(e)};
  }
}

function trimFeatureStore(k){
  const arr = state.featureStore[k]; if(!arr) return;
  if(arr.length>300) arr.splice(0, arr.length-300);
}

function updateTradeWithPrice(k, price){
  const tr = state.openTrades[k]; if(!tr) return;
  const dir = tr.dir;
  // Check TP1
  if(!tr.hitTP1){
    if((dir==="BUY" && price>=tr.tp1) || (dir==="SELL" && price<=tr.tp1)){
      tr.hitTP1 = True = true;
      // move SL to breakeven
      tr.sl = tr.entry;
      // announce
      chrome.storage.local.get(["voicePref","cfg"], r=>{
        if((r.cfg||{}).voiceOn==="on"){
          const vp=r.voicePref||{};
          chrome.tts.speak("TP one reached. Stop moved to breakeven.", { voiceName: vp.voiceName, rate: vp.rate||1, pitch: vp.pitch||1, volume: vp.volume||1, enqueue:false });
        }
      });
    }
  }
  // Trailing
  if(tr.trailing==="atr"){
    const trailGap = 1.0*tr.atr; // 1x ATR trail
    if(dir==="BUY"){
      const newSL = Math.max(tr.sl, price - trailGap);
      if(newSL>tr.sl){ tr.sl=newSL; }
    } else {
      const newSL = Math.min(tr.sl, price + trailGap);
      if(newSL<tr.sl){ tr.sl=newSL; }
    }
  }
  // Outcome resolution
  if((dir==="BUY" && price<=tr.sl) || (dir==="SELL" && price>=tr.sl)){
    finalizeTrade(k, "SL", price);
  } else if((dir==="BUY" && price>=tr.tp) || (dir==="SELL" && price<=tr.tp)){
    finalizeTrade(k, "TP", price);
  } else {
    // push updated levels to overlay
    const [symbol,timeframe,strategy] = k.split("|");
    pushPlan({ symbol,timeframe,strategy, direction:dir, entry:tr.entry, stopLoss:+tr.sl.toFixed(5), takeProfit:+tr.tp.toFixed(5), confidence:80 }, false);
  }
}

function finalizeTrade(k, outcome, price){
  const tr = state.openTrades[k]; if(!tr) return;
  const [symbol,timeframe,strategy] = k.split("|");
  const risk = Math.abs(tr.entry - tr.sl_initial || tr.entry - tr.sl); // approximate
  const rMultiple = outcome==="TP" ? Math.abs(tr.tp - tr.entry)/Math.max(1e-6,risk) : -Math.abs(tr.entry - tr.sl)/Math.max(1e-6,risk);
  // feature store record result
  const arr = state.featureStore[k] || (state.featureStore[k]=[]);
  if(arr.length){ arr[arr.length-1].resultR = rMultiple; arr[arr.length-1].outcome = outcome; }
  // voice
  chrome.storage.local.get(["voicePref","cfg"], r=>{
    if((r.cfg||{}).voiceOn==="on"){
      const vp=r.voicePref||{}; const txt = outcome==="TP" ? "Target filled." : "Stopped out.";
      chrome.tts.speak(txt, { voiceName: vp.voiceName, rate: vp.rate||1, pitch: vp.pitch||1, volume: vp.volume||1, enqueue:false });
    }
  });
  delete state.openTrades[k];
}

function wsEndpointFor(sym){
  if(sym.startsWith("C:")) return { url:"wss://socket.polygon.io/forex", chanPrefix:"C." };
  else if(/^[A-Z.\-]+$/.test(sym)) return { url:"wss://socket.polygon.io/stocks", chanPrefix:"A." };
  else return { url:"wss://socket.polygon.io/stocks", chanPrefix:"A." };
}

async function ensureWS(symbol){
  const keys = await loadKeys();
  const polyKey = keys.poly||"";
  const ep = wsEndpointFor(normalizeSymbol(symbol));
  if(state.stream.ws){ try{ state.stream.ws.close(); }catch(e){}; state.stream.ws=null; }
  const ws = new WebSocket(ep.url);
  state.stream.ws = ws;
  ws.onopen = ()=>{
    ws.send(JSON.stringify({ action:"auth", params: polyKey }));
    // subscribe to aggregate for symbol
    const chan = ep.chanPrefix + normalizeSymbol(symbol).replace(/^C:/,"");
    ws.send(JSON.stringify({ action:"subscribe", params: chan }));
  };
  ws.onmessage = (ev)=>{
    try{
      const data = JSON.parse(ev.data);
      // Polygon sends array frames; attempt to read aggregate price "p" or "c" field
      const arr = Array.isArray(data)? data : [data];
      arr.forEach(msg=>{
        const price = (msg.p||msg.c||msg.av||msg.ap||msg.vw); // attempt a price-like field
        if(typeof price==="number"){
          // update all open trades for any k with this symbol (simplify to active config)
          for(const k in state.openTrades){
            if(k.startsWith(symbol+"|")) updateTradeWithPrice(k, price);
          }
        }
      });
    }catch(e){}
  };
  ws.onclose = ()=>{ state.stream.ws=null; };
}

function expectancyFor(key, tpMult){
  const arr = state.featureStore[key]||[];
  const recent = arr.slice(-80);
  if(!recent.length) return null;
  // crude: derive win rate and average R based on stored results if present; fallback to 0.5/1R
  const withR = recent.filter(x=>typeof x.resultR==="number");
  if(!withR.length) return { exp: 0.0 };
  const wins = withR.filter(x=>x.resultR>0).length;
  const p = wins/withR.length;
  const avgW = withR.filter(x=>x.resultR>0).reduce((s,x)=>s+x.resultR,0)/Math.max(1,wins);
  const avgL = Math.abs(withR.filter(x=>x.resultR<=0).reduce((s,x)=>s+x.resultR,0)/Math.max(1,withR.length-wins));
  // scale with hypothetical tpMult vs original TP which we approximate as 1.5R
  const scale = tpMult/1.5;
  const exp = p * (avgW*scale) - (1-p) * (avgL);
  return { exp };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
  if(msg?.cmd==="TT_ANALYZE" || msg?.cmd==="TT_VISION_RUN"){
    computeAndEmit(msg.symbol||"AAPL", msg.timeframe||"5min", msg.strategy||"router", { flipOnly:false }).then(sendResponse);
    return true;
  }
  if(msg?.cmd==="TT_AUTOVISION_CFG"){
    const cfg = { on:!!msg.on, sec:Math.max(10,Number(msg.sec)||45), symbol:msg.symbol||"AAPL", timeframe:msg.timeframe||"5min", strategy:msg.strategy||"router", flipOnly:!!msg.flipOnly };
    chrome.storage.local.set({ autoVisionCfg: cfg });
    if(state.autoTimer) clearInterval(state.autoTimer);
    if(cfg.on){ state.autoTimer=setInterval(()=>{ computeAndEmit(cfg.symbol, cfg.timeframe, cfg.strategy, {flipOnly:cfg.flipOnly}); }, cfg.sec*1000); }
    sendResponse({ ok:true, ...cfg });
    return true;
  }
  if(msg?.cmd==="TT_SPEAK"){
    if(msg.text){ lastText = msg.text; }
    chrome.storage.local.get(["voicePref"], r=>{
      const vp=r.voicePref||{}; chrome.tts.speak(lastText||"No prior signal.", { voiceName: vp.voiceName, rate: vp.rate||1, pitch: vp.pitch||1, volume: vp.volume||1, enqueue:false });
    });
    sendResponse({ok:true}); return true;
  }
  if(msg?.cmd==="TT_RESET_ALERTS"){
    state.lastDirMap={}; state.heatMap={}; state.featureStore={}; state.openTrades={};
    chrome.storage.local.set({ heatMap:{} }, ()=> sendResponse({ok:true, reset:true}));
    return true;
  }
  if(msg?.cmd==="TT_MODE"){ mode = msg.mode||"beginner"; chrome.storage.local.set({ modeCfg:{mode} }); sendResponse({ok:true,mode}); return true; }
  if(msg?.cmd==="TT_GATE"){ gate = Math.max(40,Math.min(95, Number(msg.gate)||65)); chrome.storage.local.set({ gate }); sendResponse({ok:true,gate}); return true; }
  if(msg?.cmd==="TT_CFG_SAVE"){ chrome.storage.local.get(["cfg"], r=> state.cfg=r.cfg||{voiceOn:"on"}); sendResponse({ok:true}); return true; }
  if(msg?.cmd==="TT_STREAM_TOGGLE"){
    state.stream.on = (msg.poly==="on"); state.stream.trail = msg.trail||"off";
    if(state.stream.on){
      chrome.storage.local.get(["cfg"], r=>{
        const cfg=r.cfg||{}; const sym = (cfg.symbol||"AAPL");
        ensureWS(sym);
      });
    }else{
      if(state.stream.ws){ try{ state.stream.ws.close(); }catch(e){}; state.stream.ws=null; }
    }
    sendResponse({ok:true, on:state.stream.on, trail:state.stream.trail}); return true;
  }
  if(msg?.cmd==="TT_SCENARIO"){
    chrome.storage.local.get(["cfg"], r=>{
      const cfg=r.cfg||{symbol:"AAPL",timeframe:"5min",strategy:"router"};
      const key = keyFor(cfg.symbol||"AAPL", cfg.timeframe||"5min", cfg.strategy||"router");
      const res = expectancyFor(key, Number(msg.tpMult)||1.5) || {exp:null};
      sendResponse(res); 
    });
    return true;
  }
  if(msg?.cmd==="TT_SNAPSHOT"){
    chrome.tabs.captureVisibleTab(null, {format:"png"}, dataUrl=>{
      if(!dataUrl){ sendResponse({ok:false}); return; }
      const entry = { ts:Date.now(), dataUrl };
      chrome.storage.local.get(["journal"], r=>{
        const j=r.journal||[]; j.push(entry); chrome.storage.local.set({ journal:j }, ()=> sendResponse({ok:true, count:j.length}));
      });
    });
    return true;
  }
});

// Listen to storage changes for keys
chrome.storage.onChanged.addListener((changes, area)=>{
  if(area!=="local") return;
  if(changes.keys && changes.keys.newValue){ state.keys = changes.keys.newValue; }
  if(changes.cfg && changes.cfg.newValue){ state.cfg = changes.cfg.newValue; }
});
